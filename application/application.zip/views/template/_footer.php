<footer class="main-footer">
    <div class="pull-right hidden-xs">
      Simplify your business
    </div>
    <strong>Virgorasion &copy; 2018 SMKN 2 Surabaya.</strong>
  </footer>
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->